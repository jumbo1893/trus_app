enum Fine {
  amount,
  number,
}