enum GoalScreens {
  addGoals,
  addAssists
}