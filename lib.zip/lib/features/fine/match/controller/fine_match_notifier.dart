import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:trus_app/features/fine/match/screens/fine_player_screen.dart';
import 'package:trus_app/features/fine/match/state/fine_match_state.dart';
import 'package:trus_app/features/general/notifier/app_notifier.dart';
import 'package:trus_app/features/main/controller/screen_variables_notifier.dart';
import 'package:trus_app/models/api/match/match_api_model.dart';
import 'package:trus_app/models/api/season_api_model.dart';

import '../../../../common/widgets/notifier/dropdown/dropdown_state.dart';
import '../../../../models/api/player/player_api_model.dart';
import '../../../../models/api/receivedfine/received_fine_setup.dart';
import '../../../season/controller/season_dropdown_notifier.dart';
import '../../../season/season_args.dart';
import '../repository/fine_match_api_service.dart';
import '../screens/multiple_fine_players_screen.dart';

final fineMatchNotifierProvider =
    StateNotifierProvider.autoDispose<FineMatchNotifier, FineMatchState>((ref) {
  return FineMatchNotifier(
    fineApi: ref.read(fineMatchApiServiceProvider),
    screenController: ref.read(screenVariablesNotifierProvider.notifier),
    ref: ref,
  );
});

class FineMatchNotifier extends AppNotifier<FineMatchState> {
  final FineMatchApiService fineApi;
  final ScreenVariablesNotifier screenController;

  static const _seasonArgs = SeasonArgs(false, true, true);

  bool _initialized = false;
  bool _suppressSeasonListen = false;

  FineMatchNotifier({
    required this.fineApi,
    required this.screenController,
    required Ref ref,
  }) : super(ref, FineMatchState.initial()) {
    // ✅ posloucháme sezonu uvnitř notifieru (stejně jako MatchNotifier)
    ref.listen<DropdownState>(
      seasonDropdownNotifierProvider(_seasonArgs),
      (_, next) {
        if (_suppressSeasonListen) return;

        final season = next.getSelected() as SeasonApiModel?;
        if (season?.id == null) return;

        // guard proti loopu, ale spíš jen pro případ, že by někdo kliknul na dropdown a vybral stejnou sezonu, což by bylo zbytečné reloadovat
        //if (state.selectedSeason?.id == season!.id) return;
        Future.microtask(() => selectSeason(season!));
      },
      fireImmediately: false,
    );
  }

  // ==========================================================
  // INIT
  // ==========================================================
  Future<void> init({int? matchId}) async {
    if (_initialized) return;
    _initialized = true;

      // 2) vyber sezonu z dropdownu (už může být loaded), fallback na "current"
      final dropdown = ref.read(seasonDropdownNotifierProvider(_seasonArgs));
      final pickedSeason = dropdown.getSelected() as SeasonApiModel?;
      // 3) první setup: matchId když existuje, jinak seasonId
      final setup = await runUiWithResult<ReceivedFineSetup>(
                () => fineApi.setupFineMatch(
                  (matchId != null && matchId > 0) ? matchId : null,
                  (matchId == null || matchId <= 0) ? pickedSeason?.id : null,
                ),
            showLoading: true,
            successSnack: null,
          );
      _applySetup(setup);

  }

  void _applySetup(ReceivedFineSetup setup) {
    _suppressSeasonListen = true;
    try {
      ref
          .read(seasonDropdownNotifierProvider(_seasonArgs).notifier)
          .selectDropdown(setup.season);
    } finally {
      _suppressSeasonListen = false;
    }

    state = state.copyWith(
      selectedMatch: setup.match,
      matches: AsyncValue.data(setup.matchList),
      otherPlayers: setup.otherPlayers,
      playersInMatch: setup.playersInMatch,
      allPlayers: [
        ...setup.playersInMatch,
        ...setup.otherPlayers,
      ],
      playerFineSummaryByPlayerId: setup.playerFineSummaryByPlayerId,
      checkedPlayers: [],
      multiCheck: false,
    );
  }

  // ==========================================================
  // DROPDOWNS
  // ==========================================================
  Future<void> selectSeason(SeasonApiModel season) async {
    final setup = await runUiWithResult<ReceivedFineSetup>(
          () => fineApi.setupFineMatch(
            null,
            season.id,
      ),
      showLoading: true,
      successSnack: null,
    );
    _applySetup(setup);
  }

  Future<void> selectMatch(MatchApiModel match) async {
    state = state.copyWith(
      selectedMatch: match,
    );
    final setup = await runUiWithResult<ReceivedFineSetup>(
          () => fineApi.setupFineMatch(
            match.id,
            null,
      ),
      showLoading: true,
      successSnack: null,
    );
    _applySetup(setup);
  }

  void toggleCheckedPlayer(PlayerApiModel player) {
    if (!state.allPlayers.any((p) => p == player)) return;

    final current = state.checkedPlayers;
    final exists = current.any((p) => p == player);

    final next = exists
        ? current.where((p) => p != player).toList()
        : [...current, player];

    state = state.copyWith(checkedPlayers: next);
  }

  void setSelectedPlayer(PlayerApiModel player) {
    screenController.setPlayer(player);
    screenController.setMatch(state.selectedMatch!);
    changeFragment(FinePlayerScreen.id);
  }

  List<int> getCheckedPlayerIdList() {
    List<int> playerIds = [];
    for(PlayerApiModel player in state.checkedPlayers) {
      playerIds.add(player.id!);
    }
    return playerIds;
  }

  void selectAllPlayers() {
    state = state.copyWith(checkedPlayers: state.allPlayers);
  }

  void selectNotPlayingPlayers() {
    state = state.copyWith(checkedPlayers: state.otherPlayers);
  }

  void selectPlayingPlayers() {
    state = state.copyWith(checkedPlayers: state.playersInMatch);
  }

  void confirmSelection() {
    if(state.checkedPlayers.isEmpty) {
      ui.showSnack("Musí být označen aspoň jeden hráč!");
    }
    else {
      screenController.setMatch(state.selectedMatch!);
      screenController.setPlayerIdList(getCheckedPlayerIdList());
      changeFragment(MultipleFinePlayersScreen.id);
    }
  }

  void cleanCheckPlayers() {
    state = state.copyWith(checkedPlayers: []);
  }

  void switchScreen(bool multi) {
    cleanCheckPlayers();
    state = state.copyWith(multiCheck: multi);
  }

}
