enum BeerScreenMode {
  list,
  paint,
}