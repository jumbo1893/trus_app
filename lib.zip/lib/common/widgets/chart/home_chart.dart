import 'package:fl_chart/fl_chart.dart';
import 'package:flutter/material.dart';
import 'package:trus_app/models/api/home/coordinate.dart';

import 'package:trus_app/theme/app_colors.dart';
import '../../../models/api/home/chart.dart';
import 'legend.dart';

class HomeChart extends StatefulWidget {
  const HomeChart({
    super.key,
    required this.charts,
  });

  final List<Chart> charts;

  @override
  State<HomeChart> createState() => _HomeChartState();
}

class _HomeChartState extends State<HomeChart> {
  List<Color> gradientColors = [
    Colors.white54,
    Colors.grey,
  ];

  bool showFines = false;

  @override
  Widget build(BuildContext context) {
    final charts = widget.charts;

    // když nejsou data, nezobrazuj nic
    if (charts.isEmpty) return const SizedBox.shrink();

    return Column(
      children: [
        Stack(
          children: <Widget>[
            AspectRatio(
              aspectRatio: 1.70,
              child: Padding(
                padding: const EdgeInsets.only(
                  right: 18,
                  left: 12,
                  top: 24,
                  bottom: 12,
                ),
                child: LineChart(
                  beerData(charts, !showFines),
                ),
              ),
            ),
            Align(
              alignment: Alignment.center,
              child: Padding(
                padding: const EdgeInsets.only(bottom: 8.0),
                child: SizedBox(
                  height: 34,
                  child: Text(
                    showFines ? "statistika panáků" : "statistika pivek",
                    style: TextStyle(
                      fontSize: 12,
                      color: context.appColors.textPrimary,
                    ),
                  ),
                ),
              ),
            ),
            Align(
              alignment: Alignment.centerRight,
              child: Padding(
                padding: const EdgeInsets.only(bottom: 8.0),
                child: SizedBox(
                  height: 34,
                  child: TextButton(
                    onPressed: () => setState(() => showFines = !showFines),
                    child: Text(
                      showFines ? "přepni na pivka" : "přepni na panáky",
                      style: TextStyle(
                        fontSize: 12,
                        color: context.appColors.textPrimary,
                      ),
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: getLegends(charts),
        )
      ],
    );
  }

  List<Widget> getLegends(List<Chart> charts) {
    final legends = <Widget>[];
    for (final chart in charts) {
      legends.add(
        Legend(
          text: chart.player.name,
          gradientColors: getPlayerColors(charts, chart),
        ),
      );
      legends.add(SizedBox(width: 4));
    }
    return legends;
  }

  double calculateHorizontalInterval(List<int> labels) {
    if (labels.length < 2) return 2;
    return labels[1].toDouble();
  }

  List<FlSpot> getFlSpots(
      List<Coordinate> coordinates,
      bool beer,
      bool liquor,
      bool fine,
      ) {
    final spots = <FlSpot>[];
    if (beer) {
      for (int i = 0; i < coordinates.length; i++) {
        spots.add(FlSpot(i.toDouble(), coordinates[i].beerNumber.toDouble()));
      }
    }
    if (liquor) {
      for (int i = 0; i < coordinates.length; i++) {
        spots.add(FlSpot(i.toDouble(), coordinates[i].liquorNumber.toDouble()));
      }
    }
    if (fine) {
      for (int i = 0; i < coordinates.length; i++) {
        spots.add(FlSpot(i.toDouble(), coordinates[i].fineAmount.toDouble()));
      }
    }
    return spots;
  }

  Widget bottomTitleWidgets(List<Chart> charts, double value, TitleMeta meta) {
    const style = TextStyle(fontWeight: FontWeight.bold, fontSize: 12);

    if (charts.isEmpty) {
      return SideTitleWidget(axisSide: meta.axisSide, child: Text(""));
    }

    final idx = value.toInt();
    final coords = charts[0].coordinates;
    final label = (idx >= 0 && idx < coords.length) ? coords[idx].matchInitials : "";

    return SideTitleWidget(
      axisSide: meta.axisSide,
      child: Text(label, style: style),
    );
  }

  List<int> findHorizontalInterval(List<Chart> charts) {
    if (charts.isNotEmpty) {
      return findChartWithTheHighestBeerMaximum(charts).beerLabels;
    }
    return [0, 5];
  }

  double findMaxX(List<Chart> charts) {
    if (charts.isNotEmpty) {
      return (findChartWithTheHighestBeerMaximum(charts).coordinates.length - 1).toDouble();
    }
    return 4;
  }

  double findMaxY(List<Chart> charts) {
    if (charts.isNotEmpty) {
      return findChartWithTheHighestBeerMaximum(charts).beerMaximum.toDouble();
    }
    return 10;
  }

  Chart findChartWithTheHighestBeerMaximum(List<Chart> charts) {
    return charts.reduce((a, b) => a.beerMaximum > b.beerMaximum ? a : b);
  }

  LineChartData beerData(List<Chart> charts, bool beer) {
    return LineChartData(
      lineTouchData: LineTouchData(
        touchTooltipData: LineTouchTooltipData(
          getTooltipItems: (value) {
            return value
                .map(
                  (e) => LineTooltipItem(
                "${charts[e.barIndex].player.name} ${e.y.toInt()}",
                TextStyle(fontWeight: FontWeight.bold, fontSize: 14),
              ),
            )
                .toList();
          },
          tooltipBgColor: context.appColors.cardBackground,
          showOnTopOfTheChartBoxArea: true,
        ),
      ),
      gridData: FlGridData(
        show: true,
        drawVerticalLine: true,
        horizontalInterval: calculateHorizontalInterval(findHorizontalInterval(charts)),
        verticalInterval: 1,
        getDrawingHorizontalLine: (_) => FlLine(color: context.appColors.legacyAccent, strokeWidth: 1),
        getDrawingVerticalLine: (_) => FlLine(color: context.appColors.legacyAccent, strokeWidth: 1),
      ),
      titlesData: FlTitlesData(
        show: true,
        rightTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
        topTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
        bottomTitles: AxisTitles(
          sideTitles: SideTitles(
            showTitles: true,
            reservedSize: 30,
            interval: 1,
            getTitlesWidget: (value, meta) => bottomTitleWidgets(charts, value, meta),
          ),
        ),
        leftTitles: const AxisTitles(
          sideTitles: SideTitles(showTitles: true, reservedSize: 42),
        ),
      ),
      borderData: FlBorderData(show: true, border: Border.all(color: context.appColors.border)),
      minX: 0,
      maxX: findMaxX(charts),
      minY: 0,
      maxY: findMaxY(charts),
      lineBarsData: getBeerCharData(charts, beer),
    );
  }

  List<Color> getPlayerColors(List<Chart> charts, Chart chart) {
    final others = [...charts]..removeWhere((c) => c.mainPlayer);

    final gradientColorsList = <List<Color>>[
      [Colors.blue, Colors.blueGrey],
      [Colors.red, Colors.brown],
      [context.appColors.textMuted, context.appColors.disabled],
      [Colors.green, Colors.greenAccent],
      [context.appColors.legacyAccent, Colors.yellow],
    ];

    if (chart.mainPlayer) {
      return [context.appColors.legacyAccent, Colors.yellow];
    }

    final idx = others.indexOf(chart);
    if (idx < 0) return [context.appColors.textMuted, context.appColors.disabled];

    return gradientColorsList[idx % gradientColorsList.length];
  }

  List<LineChartBarData> getBeerCharData(List<Chart> charts, bool beer) {
    final list = <LineChartBarData>[];
    for (final chart in charts) {
      list.add(
        LineChartBarData(
          spots: getFlSpots(chart.coordinates, beer, !beer, false),
          isCurved: true,
          gradient: LinearGradient(colors: getPlayerColors(charts, chart)),
          barWidth: 4,
          isStrokeCapRound: true,
          dotData: const FlDotData(show: false),
          belowBarData: BarAreaData(
            show: true,
            gradient: LinearGradient(
              colors: gradientColors.map((c) => c.withOpacity(0.3)).toList(),
            ),
          ),
        ),
      );
    }
    return list;
  }
}